package ru.sber.ws.controller;

import com.sun.javafx.tools.packager.PackagerException;
import org.springframework.web.bind.annotation.RestController;
import ru.sber.model.Token;

@RestController
public interface ServiceController {

    Token getToken(String carNumber) throws PackagerException;

    Boolean updateToken(String carNumber, Long tokenId);
}
